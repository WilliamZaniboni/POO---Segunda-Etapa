package Model;

import java.util.Observable;
import java.util.Observer;

public class UpdateClass implements Observer{

    @Override
    public void update(Observable o, Object arg) {

    }

}
